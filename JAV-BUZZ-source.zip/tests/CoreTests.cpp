#include "../Source/AudioCore.h"
#include <cstdlib>
#include <iostream>
#include <new>
#include <random>
#include <stdexcept>
static bool audit = false;
static size_t allocations = 0;
void *operator new(std::size_t n) {
  if (audit)
    ++allocations;
  if (auto p = std::malloc(n ? n : 1))
    return p;
  throw std::bad_alloc();
}
void *operator new[](std::size_t n) { return ::operator new(n); }
void operator delete(void *p) noexcept { std::free(p); }
void operator delete[](void *p) noexcept { std::free(p); }
void operator delete(void *p, std::size_t) noexcept { std::free(p); }
void operator delete[](void *p, std::size_t) noexcept { std::free(p); }
void require(bool ok, const char *msg) {
  if (!ok)
    throw std::runtime_error(msg);
}
jav::Sample sample(double rate = 48000) {
  jav::Sample s;
  s.rate = rate;
  s.revision = 1;
  for (auto &c : s.raw) {
    c.resize(size_t(rate * .4));
    for (size_t i = 0; i < c.size(); i++)
      c[i] = float(.45 * std::sin(2 * jav::pi * 65.406391 * i / rate) +
                   .13 * std::sin(2 * jav::pi * 800 * i / rate));
  }
  jav::stretch(s);
  return s;
}
std::vector<float> render(const jav::Sample &s, jav::Controls p,
                          double rate = 48000) {
  jav::Engine e;
  e.prepare(rate);
  e.setSample(&s);
  e.on(36, 1);
  std::vector<float> r(size_t(rate * .8));
  for (auto &v : r)
    v = e.tick(p)[0];
  return r;
}
double rms(const std::vector<float> &v) {
  double sum = 0;
  for (size_t i = v.size() / 3; i < v.size(); i++)
    sum += v[i] * v[i];
  return std::sqrt(sum / (v.size() - v.size() / 3));
}
double diff(const std::vector<float> &a, const std::vector<float> &b) {
  double sum = 0;
  for (size_t i = a.size() / 3; i < a.size(); i++)
    sum += std::pow(a[i] - b[i], 2);
  return std::sqrt(sum / (a.size() - a.size() / 3));
}
int main() {
  try {
    auto s = sample();
    require(s.body[0].size() == s.raw[0].size() * 8, "stretch duration");
    require(std::abs(s.body[0].back()) < 1e-8, "fade endpoint");
    for (int i = 0; i < 1100; i++)
      require(s.raw[0][i] == s.body[0][i], "attack changed");
    jav::Controls p;
    p.disst = 0;
    auto dry = render(s, p);
    require(rms(dry) > .03, "silent output");
    for (int knob = 0; knob < 4; knob++) {
      std::vector<float> previous;
      for (int i = 0; i <= 10; i++) {
        auto c = p;
        if (knob == 0)
          c.gain = -36 + 4.2f * i;
        if (knob == 1)
          c.disst = i * .1f;
        if (knob == 2)
          c.filth = -1 + i * .2f;
        if (knob == 3)
          c.wet = i * .1f;
        auto out = render(s, c);
        if (i)
          require(diff(previous, out) > 1e-5, "control dead interval");
        previous = out;
      }
    }
    p.angel = true;
    auto fifth = render(s, p);
    p.angel = false;
    p.demon = true;
    auto octave = render(s, p);
    p.angel = true;
    auto seventh = render(s, p);
    require(diff(dry, fifth) > .015 && diff(fifth, octave) > .015 &&
                diff(octave, seventh) > .015,
            "harmony mode separation");
    for (double sr : {8000., 22050., 44100., 48000., 96000., 192000.}) {
      jav::Engine e;
      e.prepare(sr);
      e.setSample(&s);
      e.on(36, 1);
      std::mt19937 gen(41);
      audit = true;
      for (int i = 0; i < int(sr * 1.2); i++) {
        if (i % 113 == 0) {
          p.gain = float(gen() % 43) - 36;
          p.disst = float(gen() % 101) / 100;
          p.filth = float(gen() % 201) / 100 - 1;
          p.wet = float(gen() % 101) / 100;
          p.angel = gen() % 2;
          p.demon = gen() % 2;
        }
        if (i % 4096 == 0)
          e.on(gen() % 128, 1);
        if (i % 8192 == 0)
          e.off(36);
        auto out = e.tick(p);
        for (float v : out)
          require(std::isfinite(v) && std::abs(v) < 20,
                  "nonfinite or unstable output");
      }
      audit = false;
      e.reset();
      for (int i = 0; i < 100; i++) {
        auto out = e.tick(p);
        require(out[0] == 0 && out[1] == 0, "reset leaves audio");
      }
    }
    require(allocations == 0, "audio callback allocates");
    jav::Engine e;
    e.prepare(48000);
    e.setSample(&s);
    e.on(36, 1);
    p = {};
    p.disst = 0;
    for (int i = 0; i < 48000 * 5; i++)
      e.tick(p);
    double tail = 0;
    for (int i = 0; i < 4800; i++)
      tail += std::abs(e.tick(p)[0]);
    require(tail < .001, "held sample repeats instead of finishing");
    for (int n : {0, 1, 8, 127, 128, 129, 1000}) {
      jav::Sample tiny;
      tiny.revision = 2;
      for (auto &c : tiny.raw)
        c.assign(n, .5f);
      jav::stretch(tiny);
      e.setSample(&tiny);
      e.on(36, 1);
      for (int i = 0; i < 1000; i++)
        require(std::isfinite(e.tick(p)[0]), "short sample failure");
      e.setSample(nullptr);
    }
    std::cout << "PASS: attack, finite stretch/fade, 40 knob intervals, four "
                 "harmony modes, six sample rates, extreme MIDI, reset, "
                 "short/empty WAV buffers, zero audio allocations.\n";
    return 0;
  } catch (const std::exception &e) {
    audit = false;
    std::cerr << "FAIL: " << e.what() << '\n';
    return 1;
  }
}
