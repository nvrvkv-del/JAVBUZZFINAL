#include "../Source/AudioCore.h"
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <vector>

void check(bool v, const char *why) {
  if (!v)
    throw std::runtime_error(why);
}
static jav::Sample heldSample() {
  jav::Sample s;
  s.revision = 42;
  s.rate = 48000;
  for (auto &c : s.body) {
    c.resize(48000 * 5);
    for (size_t i = 0; i < c.size(); i++)
      c[i] = float(.45 * std::sin(2 * jav::pi * 65.406391 * i / 48000) +
                   .04 * std::sin(2 * jav::pi * 130.812782 * i / 48000));
  }
  return s;
}
int main() {
  try {
    auto s = heldSample();
    for (int knob = 0; knob < 4; knob++) {
      jav::Engine changing, reference;
      changing.prepare(48000);
      reference.prepare(48000);
      changing.setSample(&s);
      reference.setSample(&s);
      changing.on(36, 1);
      reference.on(36, 1);
      jav::Controls base;
      base.gain = -9;
      base.disst = .35f;
      auto p = base;
      for (int i = 0; i < 24000; i++) {
        changing.tick(base);
        reference.tick(base);
      }
      if (knob == 0)
        p.gain = 0;
      if (knob == 1)
        p.disst = 1;
      if (knob == 2)
        p.filth = -1;
      if (knob == 3)
        p.wet = 1;
      float firstMs = 0;
      double settled = 0;
      for (int i = 0; i < 12000; i++) {
        float delta = changing.tick(p)[0] - reference.tick(base)[0];
        if (i < 48)
          firstMs = std::max(firstMs, std::abs(delta));
        if (i > 6000)
          settled += delta * delta;
      }
      const double rms = std::sqrt(settled / 5999);
      std::cout << "Knob " << knob << ": first-ms change=" << firstMs
                << ", settled difference=" << rms << '\n';
      check(firstMs < .012f,
            "Abrupt control step reaches audio without sufficient smoothing");
      check(rms > .001, "Control change during existing held note is inaudible "
                        "in test signal");
    }
    // Every adjacent position is tested on a sustained bass, without
    // retriggering.
    for (int knob = 0; knob < 4; knob++) {
      jav::Engine e;
      e.prepare(48000);
      e.setSample(&s);
      e.on(36, 1);
      jav::Controls p;
      p.disst = .4f;
      float last = 0;
      double derivativeEnergy = 0;
      float maxStep = 0;
      for (int i = 0; i < 48000 * 3; i++) {
        const float ramp = float(i) / float(48000 * 3 - 1);
        if (knob == 0)
          p.gain = -24 + 24 * ramp;
        if (knob == 1)
          p.disst = ramp;
        if (knob == 2)
          p.filth = -1 + 2 * ramp;
        if (knob == 3)
          p.wet = ramp;
        auto y = e.tick(p);
        check(std::isfinite(y[0]) && std::isfinite(y[1]),
              "Nonfinite live sweep");
        if (i > 100) {
          const float jump = std::abs(y[0] - last);
          maxStep = std::max(maxStep, jump);
          derivativeEnergy += jump * jump;
        }
        last = y[0];
      }
      std::cout << "Live sweep " << knob
                << ": largest adjacent sample step=" << maxStep << '\n';
      check(maxStep < .04f, "Click-sized discontinuity in held bass sweep");
    }
    // Crossing Filth centre at different signal phases used to switch shared
    // state.
    for (int phase = 0; phase < 16; phase++) {
      jav::Engine a, b;
      a.prepare(48000);
      b.prepare(48000);
      a.setSample(&s);
      b.setSample(&s);
      a.on(36, 1);
      b.on(36, 1);
      jav::Controls p;
      p.filth = -.001f;
      for (int i = 0; i < 24000 + phase * 47; i++) {
        a.tick(p);
        b.tick(p);
      }
      auto target = p;
      target.filth = .001f;
      float last = 0, maxDeltaStep = 0;
      for (int i = 0; i < 4800; i++) {
        float delta = a.tick(target)[0] - b.tick(p)[0];
        maxDeltaStep = std::max(maxDeltaStep, std::abs(delta - last));
        last = delta;
      }
      check(maxDeltaStep < .003f, "Filth centre crossing clicks");
    }
    std::cout << "PASS: all four controls update a held note; step smoothing, "
                 "continuous sweeps and centre crossings.\n";
    return 0;
  } catch (const std::exception &e) {
    std::cerr << "FAIL: " << e.what() << '\n';
    return 1;
  }
}
