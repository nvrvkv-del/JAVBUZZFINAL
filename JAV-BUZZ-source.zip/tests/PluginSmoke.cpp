#include "../Source/Processor.h"
#include <iostream>
#include <stdexcept>
void check(bool value, const char *text) {
  if (!value)
    throw std::runtime_error(text);
}
void waitReady(Processor &p) {
  for (int i = 0; i < 300; i++) {
    auto s = p.statusText();
    if (s.contains("ready"))
      return;
    juce::Thread::sleep(50);
  }
  throw std::runtime_error(p.statusText().toStdString());
}
void set(Processor &p, const char *id, float value) {
  auto *param = p.state.getParameter(id);
  param->setValueNotifyingHost(param->convertTo0to1(value));
}
int main() {
  juce::ScopedJuceInitialiser_GUI gui;
  try {
    Processor p;
    waitReady(p);
    p.prepareToPlay(48000, 512);
    juce::AudioBuffer<float> b(2, 512);
    juce::MidiBuffer midi;
    midi.addEvent(juce::MidiMessage::noteOn(1, 36, 1.f), 0);
    p.processBlock(b, midi);
    check(b.getMagnitude(0, 512) > .005f, "Plugin silent after MIDI note-on");
    auto dir = juce::File::getSpecialLocation(juce::File::tempDirectory)
                   .getNonexistentChildFile("jav-buzz-smoke", "");
    check(dir.createDirectory().wasOk(), "Temp directory");
    set(p, "dist", .73f);
    set(p, "angel", 1);
    check(p.savePreset(dir.getChildFile("test.javpreset")).wasOk(),
          "Save preset");
    p.initPreset();
    check(p.loadPreset(dir.getChildFile("test.javpreset")).wasOk(),
          "Load preset");
    waitReady(p);
    check(std::abs(p.state.getRawParameterValue("dist")->load() - .73f) < .002f,
          "Preset parameter recall");
    juce::MemoryBlock state;
    p.getStateInformation(state);
    set(p, "dist", .1f);
    p.setStateInformation(state.getData(), int(state.getSize()));
    waitReady(p);
    check(std::abs(p.state.getRawParameterValue("dist")->load() - .73f) < .002f,
          "Host state recall");
    // Import a real WAV, save its portable preset, move both, then restore.
    auto wave = dir.getChildFile("original.wav");
    {
      juce::WavAudioFormat format;
      std::unique_ptr<juce::OutputStream> out = wave.createOutputStream();
      check(bool(out), "Create WAV stream");
      auto options = juce::AudioFormatWriterOptions{}
                         .withSampleRate(48000)
                         .withNumChannels(1)
                         .withBitsPerSample(16);
      auto writer = format.createWriterFor(out, options);
      check(bool(writer), "Create WAV writer");
      juce::AudioBuffer<float> audio(1, 4800);
      for (int i = 0; i < 4800; i++)
        audio.setSample(0, i,
                        float(.4 * std::sin(2 * jav::pi * 65.4 * i / 48000)));
      check(writer->writeFromAudioSampleBuffer(audio, 0, 4800), "Write WAV");
    }
    p.importWav(wave);
    waitReady(p);
    auto portable = dir.getChildFile("bank");
    portable.createDirectory();
    check(p.savePreset(portable.getChildFile("Bass.javpreset")).wasOk(),
          "Save WAV preset");
    auto moved = dir.getChildFile("moved");
    check(portable.moveFileTo(moved), "Move preset bank");
    check(p.loadPreset(moved.getChildFile("Bass.javpreset")).wasOk(),
          "Portable sample reference");
    waitReady(p);
    auto output =
        juce::File::getCurrentWorkingDirectory().getChildFile("ui-previews");
    output.createDirectory();
    std::unique_ptr<juce::AudioProcessorEditor> editor(p.createEditor());
    const char *names[] = {"sleep", "angel", "demon", "aliens"};
    for (int mode = 0; mode < 4; mode++) {
      set(p, "angel", mode == 1 || mode == 3);
      set(p, "demon", mode == 2 || mode == 3);
      for (int frame = 0; frame < 18; frame++) {
        juce::Thread::sleep(34);
        juce::Timer::callPendingTimersSynchronously();
      }
      auto image = editor->createComponentSnapshot(editor->getLocalBounds());
      check(image.isValid() && image.getWidth() == 420 &&
                image.getHeight() == 690,
            "Editor snapshot");
      auto stream = output.getChildFile(juce::String(names[mode]) + ".png")
                        .createOutputStream();
      check(stream && juce::PNGImageFormat().writeImageToStream(image, *stream),
            "Write screenshot");
    }
    editor.reset();
    dir.deleteRecursively();
    std::cout << "PASS: MIDI output, preset and host-state recall, WAV import, "
                 "portable preset, four UI snapshots.\n";
    return 0;
  } catch (const std::exception &e) {
    std::cerr << "FAIL: " << e.what() << '\n';
    return 1;
  }
}
