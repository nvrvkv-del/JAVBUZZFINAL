#include "Editor.h"
#include <BinaryData.h>
namespace {
const juce::Colour ink{0xff151c29}, green{0xffb2ff36}, pink{0xffff68bb},
    paper{0xffece8d7}, blue{0xff385db0};
void font(juce::Graphics &g, float size, bool bold = false) {
  g.setFont(juce::Font(
      juce::FontOptions(size, bold ? juce::Font::bold : juce::Font::plain)));
}
} // namespace
void Editor::KnobLook::drawButtonText(juce::Graphics &g, juce::TextButton &b,
                                      bool over, bool down) {
  if (b.getButtonText().isNotEmpty()) {
    juce::LookAndFeel_V4::drawButtonText(g, b, over, down);
    return;
  }
  g.setColour(ink);
  juce::Path p;
  p.startNewSubPath(10, 20);
  p.lineTo(10, 38);
  p.lineTo(38, 38);
  p.lineTo(38, 20);
  p.lineTo(25, 20);
  p.lineTo(21, 16);
  p.lineTo(10, 16);
  p.closeSubPath();
  g.strokePath(p, juce::PathStrokeType(2.5f));
  g.drawLine(24, 22, 24, 33, 2.5f);
  g.drawLine(19, 28, 24, 33, 2.5f);
  g.drawLine(24, 33, 29, 28, 2.5f);
}
void Editor::KnobLook::drawRotarySlider(juce::Graphics &g, int x, int y, int w,
                                        int h, float value, float start,
                                        float end, juce::Slider &) {
  auto r =
      juce::Rectangle<float>(float(x), float(y), float(w), float(h)).reduced(7);
  float size = std::min(r.getWidth(), r.getHeight());
  r = r.withSizeKeepingCentre(size, size);
  auto c = r.getCentre();
  g.setColour(ink);
  g.fillEllipse(r.translated(2, 4));
  g.setColour(paper);
  g.fillEllipse(r);
  g.setColour(ink);
  g.drawEllipse(r, 3);
  for (int i = 0; i < 18; i++) {
    float a = float(i) * juce::MathConstants<float>::twoPi / 18;
    auto p = c + juce::Point<float>(std::sin(a), -std::cos(a)) * size * .43f;
    g.drawLine(p.x, p.y, p.x + std::sin(a) * 3, p.y - std::cos(a) * 3, 1.5f);
  }
  juce::Path arc;
  arc.addCentredArc(c.x, c.y, size * .57f, size * .57f, 0, start,
                    start + (end - start) * value, true);
  g.setColour(green);
  g.strokePath(arc, juce::PathStrokeType(3));
  float a = start + (end - start) * value;
  g.setColour(ink);
  g.drawLine(c.x, c.y, c.x + std::sin(a) * size * .32f,
             c.y - std::cos(a) * size * .32f, 4);
}
void Editor::Spirit::paintButton(juce::Graphics &g, bool over, bool) {
  g.addTransform(juce::AffineTransform::translation(0, (1 - awake) * 13));
  auto robe = alien ? green : (angel ? paper : pink);
  float cx = getWidth() * .5f;
  float head = 24 - awake * 5;
  if (angel && !alien) {
    g.setColour(paper);
    g.fillEllipse(cx - 32, 39, 25, 32);
    g.fillEllipse(cx + 7, 39, 25, 32);
    g.setColour(ink);
    g.drawEllipse(cx - 32, 39, 25, 32, 2);
    g.drawEllipse(cx + 7, 39, 25, 32, 2);
    g.setColour(green);
    g.drawEllipse(cx - 15, head - 16, 30, 8, 3);
  }
  juce::Path body;
  body.startNewSubPath(cx - 12, head + 15);
  body.lineTo(cx + 12, head + 15);
  body.lineTo(cx + 23, 81);
  body.lineTo(cx - 23, 81);
  body.closeSubPath();
  g.setColour(robe);
  g.fillPath(body);
  g.setColour(ink);
  g.strokePath(body, juce::PathStrokeType(over ? 3.5f : 2.5f));
  g.setColour(robe);
  g.fillEllipse(cx - 15, head - 6, 30, 29);
  g.setColour(ink);
  g.drawEllipse(cx - 15, head - 6, 30, 29, 2.5f);
  if (!angel && !alien) {
    juce::Path horns;
    horns.addTriangle(cx - 13, head + 1, cx - 16, head - 16, cx - 3, head - 3);
    horns.addTriangle(cx + 13, head + 1, cx + 16, head - 16, cx + 3, head - 3);
    g.setColour(pink);
    g.fillPath(horns);
    g.setColour(ink);
    g.strokePath(horns, juce::PathStrokeType(2));
  }
  g.setColour(ink);
  if (awake > .5f) {
    if (alien) {
      g.fillEllipse(cx - 11, head + 3, 9, 12);
      g.fillEllipse(cx + 2, head + 3, 9, 12);
    } else {
      g.fillEllipse(cx - 8, head + 4, 4, 6);
      g.fillEllipse(cx + 4, head + 4, 4, 6);
    }
  } else {
    g.drawLine(cx - 10, head + 10, cx - 3, head + 10, 2);
    g.drawLine(cx + 3, head + 10, cx + 10, head + 10, 2);
  }
  font(g, 17, true);
  g.drawText(alien   ? "7th"
             : angel ? "5th"
                     : "8th",
             int(cx - 24), 49, 48, 24, juce::Justification::centred);
  if (awake < .2f) {
    g.setColour(paper);
    font(g, 13, true);
    g.drawText("z z", int(cx + 13), 0, 30, 18, juce::Justification::centred);
  }
}
Editor::Editor(Processor &p) : AudioProcessorEditor(p), processor(p) {
  setSize(420, 690);
  character = juce::ImageCache::getFromMemory(BinaryData::Character_png,
                                              BinaryData::Character_pngSize);
  setLookAndFeel(&look);
  look.setColour(juce::ComboBox::backgroundColourId, ink);
  look.setColour(juce::ComboBox::textColourId, paper);
  look.setColour(juce::ComboBox::outlineColourId, paper);
  look.setColour(juce::TextButton::buttonColourId, pink);
  look.setColour(juce::TextButton::textColourOffId, ink);
  const char *ids[] = {"gain", "dist", "filt", "reverb"};
  const char *labels[] = {"Gain", "Disst", "Filth", "Wet"};
  for (int i = 0; i < 4; i++) {
    auto &s = knobs[i];
    addAndMakeVisible(s);
    s.setName(labels[i]);
    s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    s.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 76, 20);
    s.setColour(juce::Slider::textBoxTextColourId, paper);
    s.setColour(juce::Slider::textBoxOutlineColourId,
                juce::Colours::transparentBlack);
    s.setRotaryParameters(juce::MathConstants<float>::pi * 1.25f,
                          juce::MathConstants<float>::pi * 2.75f, true);
    knobAttachments[i] =
        std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
            p.state, ids[i], s);
    s.setDoubleClickReturnValue(true, i == 0 ? -9 : i == 1 ? .25 : 0);
    if (i == 0)
      s.setTextValueSuffix(" dB");
    else {
      s.textFromValueFunction = [](double v) {
        return juce::String(juce::roundToInt(v * 100)) + "%";
      };
      s.valueFromTextFunction = [](const juce::String &t) {
        return t.getDoubleValue() / 100;
      };
    }
  }
  knobs[0].setTooltip("Output level. Double-click resets.");
  knobs[1].setTooltip(
      "Bass-preserving drive, then folding. Double-click resets.");
  knobs[2].setTooltip(
      "Left: dark low-pass. Centre: open. Right: thin high-pass.");
  knobs[3].setTooltip("Short, dark reverb with a bass-cut send.");
  addAndMakeVisible(angel);
  addAndMakeVisible(demon);
  angel.setTooltip("Wake angel: perfect fifth. Both awake: minor seventh.");
  demon.setTooltip("Wake demon: octave. Both awake: minor seventh.");
  angelAttachment =
      std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
          p.state, "angel", angel);
  demonAttachment =
      std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
          p.state, "demon", demon);
  addAndMakeVisible(presets);
  addAndMakeVisible(root);
  addAndMakeVisible(importButton);
  addAndMakeVisible(saveButton);
  addAndMakeVisible(folderButton);
  addAndMakeVisible(status);
  for (int i = 0; i < 128; i++)
    root.addItem(juce::String(i) + " / " +
                     juce::MidiMessage::getMidiNoteName(i, true, false, 3),
                 i + 1);
  rootAttachment =
      std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(
          p.state, "root", root);
  root.setTooltip("Original WAV pitch as a MIDI note number. 36 is the "
                  "built-in bass root.");
  status.setColour(juce::Label::textColourId, paper);
  status.setFont(juce::Font(juce::FontOptions(11)));
  importButton.setTooltip("Import mono or stereo WAV (up to 30 seconds)");
  saveButton.setTooltip("Save controls and a copy of the WAV as a .javpreset");
  folderButton.setTooltip("Open preset folder");
  refreshPresets();
  presets.onChange = [this] {
    int id = presets.getSelectedId();
    if (id == 1)
      processor.initPreset();
    else if (id == 2)
      choosePreset();
    else if (id >= 10 && id - 10 < presetFiles.size())
      report(processor.loadPreset(presetFiles[id - 10]));
  };
  importButton.onClick = [this] { chooseWave(); };
  saveButton.onClick = [this] { chooseSave(); };
  folderButton.onClick = [this] { processor.presetFolder().startAsProcess(); };
  startTimerHz(30);
}
Editor::~Editor() {
  stopTimer();
  setLookAndFeel(nullptr);
}
void Editor::resized() {
  presets.setBounds(22, 91, 244, 29);
  saveButton.setBounds(273, 91, 59, 29);
  folderButton.setBounds(339, 91, 58, 29);
  angel.setBounds(37, 204, 75, 99);
  demon.setBounds(306, 204, 75, 99);
  importButton.setBounds(345, 413, 48, 55);
  root.setBounds(270, 484, 125, 25);
  status.setBounds(22, 516, 376, 24);
  for (int i = 0; i < 4; i++)
    knobs[i].setBounds(22 + i * 97, 565, 86, 92);
}
void Editor::paint(juce::Graphics &g) {
  g.fillAll(ink);
  auto enclosure = getLocalBounds().toFloat().reduced(5);
  g.setColour(blue);
  g.fillRoundedRectangle(enclosure, 16);
  g.setColour(ink);
  g.drawRoundedRectangle(enclosure, 16, 3);
  for (int y = 19; y < 680; y += 9)
    for (int x = 16; x < 407; x += 11) {
      g.setColour(ink.withAlpha(.10f));
      g.fillEllipse(float(x), float(y), 1.3f, 1.3f);
    }
  g.setColour(green);
  font(g, 42, true);
  g.drawText("JAV-BUZZ", 16, 18, 388, 52, juce::Justification::centred);
  g.setColour(paper);
  font(g, 11, true);
  g.drawText("JAV UNIVERSE / BASS INSTRUMENT", 16, 67, 388, 17,
             juce::Justification::centred);
  if (character.isValid())
    g.drawImageWithin(character, 72, 127, 276, 271,
                      juce::RectanglePlacement::centred);
  g.setColour(ink);
  g.fillRoundedRectangle(22, 401, 376, 76, 6);
  g.setColour(paper);
  g.drawRoundedRectangle(22, 401, 376, 76, 6, 2);
  {
    juce::Graphics::ScopedSaveState saved(g);
    g.reduceClipRegion(juce::Rectangle<int>(29, 407, 306, 64));
    auto shape = processor.sampleShape();
    juce::Path silhouette;
    for (int i = 0; i < 128; i++) {
      float x = 30 + i * 2.38f, y = 439 - shape[i] * 23;
      if (i == 0)
        silhouette.startNewSubPath(x, y);
      else
        silhouette.lineTo(x, y);
    }
    for (int i = 127; i >= 0; i--)
      silhouette.lineTo(30 + i * 2.38f, 439 + shape[i] * 23);
    silhouette.closeSubPath();
    g.setColour(green.withAlpha(.18f));
    g.fillPath(silhouette);
    juce::Path wave;
    auto w = processor.scopeWrite.load(std::memory_order_acquire);
    for (int i = 0; i < 256; i++) {
      float s = processor.scope[(w + unsigned(i)) % 256].load(
          std::memory_order_relaxed);
      float y = 439 - std::tanh(s * 3) * 26;
      float x = 30 + i * 1.18f;
      if (i == 0)
        wave.startNewSubPath(x, y);
      else
        wave.lineTo(x, y);
    }
    g.setColour(green.withAlpha(.18f));
    g.strokePath(wave, juce::PathStrokeType(5 + energy * 3));
    g.setColour(green);
    g.strokePath(wave, juce::PathStrokeType(1.7f));
  }
  // Icon is drawn over the child button in its own look-and-feel callback below
  // via button text glyph-free path.
  g.setColour(paper);
  font(g, 12, true);
  g.drawText("SAMPLE ROOT / MIDI", 22, 484, 241, 25,
             juce::Justification::centredLeft);
  const char *labels[] = {"Gain", "Disst", "Filth", "Wet"};
  font(g, 16, true);
  for (int i = 0; i < 4; i++)
    g.drawText(labels[i], 22 + i * 97, 545, 86, 22,
               juce::Justification::centred);
  font(g, 10, true);
  g.setColour(paper.withAlpha(.8f));
  g.drawText("ONE SHOT. LONG SHADOW.", 18, 665, 384, 16,
             juce::Justification::centred);
  g.setColour(ink);
  for (auto p :
       {juce::Point<float>(17, 17), {403, 17}, {17, 673}, {403, 673}}) {
    g.fillEllipse(p.x - 3, p.y - 3, 6, 6);
    g.setColour(paper.withAlpha(.5f));
    g.drawLine(p.x - 2, p.y, p.x + 2, p.y, 1);
    g.setColour(ink);
  }
}
void Editor::timerCallback() {
  bool a = angel.getToggleState(), d = demon.getToggleState();
  angel.alien = demon.alien = a && d;
  angel.awake += (float(a) - angel.awake) * .25f;
  demon.awake += (float(d) - demon.awake) * .25f;
  energy = std::max(processor.level.exchange(0), energy * .86f);
  phase += .08f;
  if (noticeFrames > 0)
    --noticeFrames;
  status.setText(noticeFrames > 0 ? notice : processor.statusText(),
                 juce::dontSendNotification);
  repaint();
}
void Editor::refreshPresets() {
  presetFiles = processor.presetFolder().findChildFiles(juce::File::findFiles,
                                                        false, "*.javpreset");
  presets.clear(juce::dontSendNotification);
  presets.addItem("INIT BASS", 1);
  presets.addItem("Open preset...", 2);
  presets.addSeparator();
  for (int i = 0; i < presetFiles.size(); i++)
    presets.addItem(presetFiles[i].getFileNameWithoutExtension(), 10 + i);
  presets.setSelectedId(1, juce::dontSendNotification);
}
void Editor::report(const juce::Result &r) {
  if (r.failed()) {
    notice = r.getErrorMessage();
    noticeFrames = 240;
    status.setTooltip(notice);
  }
}
void Editor::chooseWave() {
  chooser = std::make_unique<juce::FileChooser>(
      "Import bass WAV", processor.sampleFolder(), "*.wav");
  chooser->launchAsync(juce::FileBrowserComponent::openMode |
                           juce::FileBrowserComponent::canSelectFiles,
                       [safe = juce::Component::SafePointer<Editor>(this)](
                           const juce::FileChooser &c) {
                         if (safe && c.getResult().existsAsFile()) {
                           safe->processor.importWav(c.getResult());
                           safe->presets.setText("CUSTOM WAV",
                                                 juce::dontSendNotification);
                         }
                       });
}
void Editor::chooseSave() {
  chooser = std::make_unique<juce::FileChooser>(
      "Save JAV-BUZZ preset",
      processor.presetFolder().getChildFile("My Bass.javpreset"),
      "*.javpreset");
  chooser->launchAsync(
      juce::FileBrowserComponent::saveMode |
          juce::FileBrowserComponent::canSelectFiles |
          juce::FileBrowserComponent::warnAboutOverwriting,
      [safe = juce::Component::SafePointer<Editor>(this)](
          const juce::FileChooser &c) {
        if (safe && c.getResult() != juce::File()) {
          auto f = c.getResult().withFileExtension("javpreset");
          auto r = safe->processor.savePreset(f);
          safe->report(r);
          if (r.wasOk()) {
            safe->refreshPresets();
            safe->presets.setText(f.getFileNameWithoutExtension(),
                                  juce::dontSendNotification);
            safe->notice = "Preset + WAV saved";
            safe->noticeFrames = 90;
          }
        }
      });
}
void Editor::choosePreset() {
  chooser = std::make_unique<juce::FileChooser>(
      "Open JAV-BUZZ preset", processor.presetFolder(), "*.javpreset");
  chooser->launchAsync(juce::FileBrowserComponent::openMode |
                           juce::FileBrowserComponent::canSelectFiles,
                       [safe = juce::Component::SafePointer<Editor>(this)](
                           const juce::FileChooser &c) {
                         if (safe && c.getResult().existsAsFile()) {
                           auto r = safe->processor.loadPreset(c.getResult());
                           safe->report(r);
                           if (r.wasOk())
                             safe->presets.setText(
                                 c.getResult().getFileNameWithoutExtension(),
                                 juce::dontSendNotification);
                         }
                       });
}
