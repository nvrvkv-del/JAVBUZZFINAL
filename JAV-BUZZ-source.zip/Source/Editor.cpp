#include "Editor.h"
#include <BinaryData.h>
namespace {
const juce::Colour ink{0xff080909}, green{0xff65ff00}, pink{0xffff0084},
    paper{0xfff3ebce}, yellow{0xfff0eb00};
void font(juce::Graphics &g, float size, bool bold = false) {
  g.setFont(juce::Font(juce::FontOptions(
      "Georgia", size, bold ? juce::Font::bold : juce::Font::plain)));
}
} // namespace
void Editor::SkinLook::drawRotarySlider(juce::Graphics &g, int x, int y, int w,
                                        int h, float value, float start,
                                        float end, juce::Slider &slider) {
  const auto c = juce::Point<float>(x + w * .5f, y + h * .5f);
  const float size = std::min(w, h) * .91f, radius = size * .5f;
  g.setColour(paper);
  for (int i = 0; i <= 10; ++i) {
    const float a = start + (end - start) * i / 10.f;
    const auto d = juce::Point<float>(std::sin(a), -std::cos(a));
    g.drawLine({c + d * (radius * .94f), c + d * (radius * 1.08f)}, 2.f);
  }
  if (dial.isValid())
    g.drawImage(dial,
                juce::Rectangle<float>(c.x - radius, c.y - radius, size, size));
  const auto colour = slider.findColour(juce::Slider::rotarySliderFillColourId);
  const float a = start + (end - start) * value;
  const auto direction = juce::Point<float>(std::sin(a), -std::cos(a));
  g.setColour(ink);
  g.drawLine({c + direction * radius * .18f, c + direction * radius * .69f},
             7.5f);
  g.setColour(colour);
  g.drawLine({c + direction * radius * .18f, c + direction * radius * .69f},
             5.2f);
}
juce::Font Editor::SkinLook::getComboBoxFont(juce::ComboBox &c) {
  return juce::Font(
      juce::FontOptions("Georgia", c.getHeight() * .64f, juce::Font::bold));
}
void Editor::SkinLook::positionComboBoxText(juce::ComboBox &box,
                                            juce::Label &label) {
  label.setBounds(3, 0, box.getWidth() - 25, box.getHeight());
  label.setFont(getComboBoxFont(box));
}
void Editor::SkinLook::drawComboBox(juce::Graphics &g, int w, int h, bool, int,
                                    int, int, int, juce::ComboBox &) {
  g.setColour(paper);
  juce::Path p;
  p.addTriangle(float(w - 18), h * .4f, float(w - 8), h * .4f, float(w - 13),
                h * .66f);
  g.fillPath(p);
}
void Editor::SkinLook::drawButtonBackground(juce::Graphics &g, juce::Button &b,
                                            const juce::Colour &, bool over,
                                            bool down) {
  if (over || down) {
    g.setColour(paper.withAlpha(down ? .23f : .10f));
    g.fillRoundedRectangle(b.getLocalBounds().toFloat().reduced(1), 2);
  }
}
void Editor::SkinLook::drawButtonText(juce::Graphics &g, juce::TextButton &b,
                                      bool, bool) {
  if (b.getButtonText().isEmpty())
    return; // Imported artwork is already on the panel.
  g.setColour(paper);
  float w = float(b.getWidth()), h = float(b.getHeight());
  if (b.getButtonText() == "save") {
    auto r = juce::Rectangle<float>(w * .22f, h * .18f, w * .56f, h * .66f);
    g.drawRoundedRectangle(r, 1.2f, 1.5f);
    g.fillRect(w * .37f, h * .20f, w * .25f, h * .19f);
    g.drawRect(w * .34f, h * .53f, w * .32f, h * .28f, 1.1f);
  } else {
    for (int i = 0; i < 3; i++)
      g.fillEllipse(w * (.22f + i * .23f), h * .43f, w * .11f, w * .11f);
  }
}
void Editor::Spirit::advance(int mode, float dt) {
  const float k = 1 - std::exp(-dt * 16);
  for (int i = 0; i < 3; i++)
    opacity[i] += ((i == mode ? 1.f : 0.f) - opacity[i]) * k;
  lift += ((mode == 0 ? 0.f : 1.f) - lift) * k;
}
void Editor::Spirit::paintButton(juce::Graphics &g, bool over, bool) {
  if (!sprites.isValid())
    return;
  const int cellW = sprites.getWidth() / 3, cellH = sprites.getHeight() / 2;
  const float size = float(std::min(getWidth(), getHeight()));
  const auto target = juce::Rectangle<float>((getWidth() - size) * .5f,
                                             7 * (1 - lift), size, size);
  if (over) {
    g.setColour(green.withAlpha(.12f));
    g.fillEllipse(target.reduced(8));
  }
  for (int i = 0; i < 3; i++)
    if (opacity[i] > .001f) {
      g.setOpacity(opacity[i]);
      g.drawImage(sprites, int(target.getX()), int(target.getY()),
                  int(target.getWidth()), int(target.getHeight()), i * cellW,
                  row * cellH, cellW, cellH);
    }
  g.setOpacity(1);
}
Editor::Editor(Processor &p) : AudioProcessorEditor(p), processor(p) {
  panel = juce::ImageCache::getFromMemory(BinaryData::Panel_png,
                                          BinaryData::Panel_pngSize);
  look.dial = juce::ImageCache::getFromMemory(BinaryData::Knob_png,
                                              BinaryData::Knob_pngSize);
  angel.sprites = demon.sprites = juce::ImageCache::getFromMemory(
      BinaryData::Spirits_png, BinaryData::Spirits_pngSize);
  setLookAndFeel(&look);
  look.setColour(juce::ComboBox::textColourId, paper);
  look.setColour(juce::PopupMenu::backgroundColourId, ink);
  look.setColour(juce::PopupMenu::textColourId, paper);
  look.setColour(juce::PopupMenu::highlightedBackgroundColourId, pink);
  look.setColour(juce::PopupMenu::highlightedTextColourId, ink);
  const char *ids[] = {"gain", "dist", "filt", "reverb"};
  const char *labels[] = {"Gain", "Disst", "Filth", "Wet"};
  const juce::Colour colors[] = {green, pink, yellow, juce::Colour(0xffa845ff)};
  for (int i = 0; i < 4; i++) {
    auto &s = knobs[i];
    addAndMakeVisible(s);
    s.setName(labels[i]);
    s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    s.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
    s.setRotaryParameters(juce::MathConstants<float>::pi * 1.25f,
                          juce::MathConstants<float>::pi * 2.75f, true);
    s.setColour(juce::Slider::rotarySliderFillColourId, colors[i]);
    s.setMouseDragSensitivity(360);
    s.setVelocityBasedMode(false);
    s.setVelocityModeParameters(.12, 1, 0.0, true,
                                juce::ModifierKeys::shiftModifier);
    knobAttachments[i] =
        std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
            p.state, ids[i], s);
    s.setDoubleClickReturnValue(true, i == 0 ? -9 : i == 1 ? .25 : 0);
    s.setPopupDisplayEnabled(true, true, this);
    if (i == 0) {
      s.textFromValueFunction = [](double v) {
        return juce::String(v, 1) + " dB";
      };
      s.valueFromTextFunction = [](const juce::String &t) {
        return t.getDoubleValue();
      };
    } else {
      s.textFromValueFunction = [](double v) {
        return juce::String(v * 100, 1) + "%";
      };
      s.valueFromTextFunction = [](const juce::String &t) {
        return t.getDoubleValue() / 100;
      };
    }
  }
  knobs[0].setTooltip(
      "Gain / output level. Shift-drag for fine control. Double-click resets.");
  knobs[1].setTooltip(
      "Disst / continuous full-band saturation with a little clean bass.");
  knobs[2].setTooltip("Filth / left darkens, centre opens, right removes lows. "
                      "Continuous while playing.");
  knobs[3].setTooltip("Wet / dark bass-cut reverb. Double-click resets.");
  addAndMakeVisible(angel);
  addAndMakeVisible(demon);
  angel.setTooltip("Angel: perfect fifth. Both awake: minor seventh.");
  demon.setTooltip("Demon: octave. Both awake: minor seventh.");
  angelAttachment =
      std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
          p.state, "angel", angel);
  demonAttachment =
      std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(
          p.state, "demon", demon);
  addAndMakeVisible(presets);
  addAndMakeVisible(importButton);
  addAndMakeVisible(saveButton);
  addAndMakeVisible(optionsButton);
  importButton.setName("Import WAV");
  saveButton.setName("Save preset");
  optionsButton.setName("Sample and preset options");
  importButton.setTooltip("Import WAV, or drop a WAV on this panel. Your bass "
                          "pack can stay anywhere.");
  saveButton.setTooltip("Save a .javpreset and its WAV");
  optionsButton.setTooltip("Sample root, preset folder and sample storage");
  refreshPresets();
  presets.onChange = [this] {
    const int id = presets.getSelectedId();
    if (id == 1)
      processor.initPreset();
    else if (id == 2)
      choosePreset();
    else if (id >= 10 && id - 10 < presetFiles.size())
      report(processor.loadPreset(presetFiles[id - 10]));
  };
  importButton.onClick = [this] { chooseWave(); };
  saveButton.onClick = [this] { chooseSave(); };
  optionsButton.onClick = [this] { showOptions(); };
  setResizable(true, false);
  getConstrainer()->setFixedAspectRatio(420.0 / 690.0);
  setResizeLimits(320, 526, 630, 1035);
  setSize(400, 657);
  lastFrame = juce::Time::getMillisecondCounterHiRes();
  startTimerHz(40);
}
Editor::~Editor() {
  stopTimer();
  setLookAndFeel(nullptr);
}
void Editor::resized() {
  const float sx = getWidth() / 420.f, sy = getHeight() / 690.f;
  auto place = [&](juce::Component &c, int x, int y, int w, int h) {
    c.setBounds(juce::Rectangle<float>(float(x) * sx, float(y) * sy,
                                       float(w) * sx, float(h) * sy)
                    .toNearestInt());
  };
  place(presets, 73, 20, 208, 28);
  place(saveButton, 283, 20, 26, 28);
  place(optionsButton, 313, 20, 29, 28);
  place(angel, 25, 203, 90, 95);
  place(demon, 307, 203, 90, 95);
  place(importButton, 318, 490, 84, 80);
  for (int i = 0; i < 4; i++)
    place(knobs[i], 22 + i * 96, 574, 82, 64);
}
void Editor::paint(juce::Graphics &g) {
  g.addTransform(
      juce::AffineTransform::scale(getWidth() / 420.f, getHeight() / 690.f));
  if (panel.isValid())
    g.drawImage(panel, juce::Rectangle<float>(0, 0, 420, 690));
  else
    g.fillAll(ink);
  drawScope(g);
  const char *labels[] = {"Gain", "Disst", "Filth", "Wet"};
  font(g, 16, true);
  for (int i = 0; i < 4; i++) {
    g.setColour(ink);
    g.drawText(labels[i], 23 + i * 96, 636, 82, 21,
               juce::Justification::centred);
    g.setColour(paper);
    g.drawText(labels[i], 22 + i * 96, 635, 82, 21,
               juce::Justification::centred);
  }
}
void Editor::drawScope(juce::Graphics &g) {
  juce::Graphics::ScopedSaveState save(g);
  g.reduceClipRegion(juce::Rectangle<int>(26, 495, 273, 68));
  constexpr float mid = 529;
  juce::Path envelope;
  for (int i = 0; i < 128; i++) {
    const float x = 27 + i * 2.13f, y = mid - shape[i] * 22;
    if (i == 0)
      envelope.startNewSubPath(x, y);
    else
      envelope.lineTo(x, y);
  }
  for (int i = 127; i >= 0; i--)
    envelope.lineTo(27 + i * 2.13f, mid + shape[i] * 22);
  envelope.closeSubPath();
  g.setColour(green.withAlpha(.10f));
  g.fillPath(envelope);
  const float boost = std::min(9.f, 1.2f / std::max(.12f, energy));
  for (int trace = 2; trace >= 0; --trace) {
    juce::Path line;
    for (int i = 0; i < 256; i++) {
      const float x = 27 + i * 1.062f;
      const float y = mid - std::tanh(traces[trace][i] * boost) * 27;
      if (i == 0)
        line.startNewSubPath(x, y);
      else
        line.lineTo(x, y);
    }
    g.setColour(green.withAlpha(trace == 0 ? .11f : .035f));
    g.strokePath(line, juce::PathStrokeType(trace == 0 ? 7.f : 4.f));
    g.setColour(green.withAlpha(trace == 0 ? 1.f : trace == 1 ? .28f : .12f));
    g.strokePath(line, juce::PathStrokeType(trace == 0 ? 1.6f : 1.f));
  }
  if (noticeFrames > 0 || (!currentStatus.contains("ready"))) {
    g.setColour(ink.withAlpha(.90f));
    g.fillRect(27, 503, 270, 50);
    g.setColour(paper);
    font(g, 11, true);
    g.drawFittedText(noticeFrames > 0 ? notice : currentStatus, 32, 506, 260,
                     44, juce::Justification::centred, 3);
  }
}
void Editor::timerCallback() {
  const double now = juce::Time::getMillisecondCounterHiRes();
  const float dt = float(std::clamp((now - lastFrame) * .001, 0.001, .1));
  lastFrame = now;
  const bool a = angel.getToggleState(), d = demon.getToggleState();
  angel.advance(a ? (d ? 2 : 1) : 0, dt);
  demon.advance(d ? (a ? 2 : 1) : 0, dt);
  energy = std::max(processor.level.exchange(0), energy * std::exp(-dt * 4));
  traces[2] = traces[1];
  traces[1] = traces[0];
  const auto w = processor.scopeWrite.load(std::memory_order_acquire);
  for (unsigned i = 0; i < 256; i++)
    traces[0][i] =
        processor.scope[(w + i) % 256].load(std::memory_order_relaxed);
  currentStatus = processor.statusText();
  shape = processor.sampleShape();
  if (noticeFrames > 0)
    --noticeFrames;
  repaint();
}
bool Editor::isInterestedInFileDrag(const juce::StringArray &files) {
  return files.size() == 1 && juce::File(files[0]).hasFileExtension("wav");
}
void Editor::filesDropped(const juce::StringArray &files, int, int) {
  if (isInterestedInFileDrag(files)) {
    processor.importWav(juce::File(files[0]));
    presets.setText("CUSTOM WAV", juce::dontSendNotification);
  }
}
void Editor::showOptions() {
  juce::PopupMenu menu, notes;
  const int root = int(processor.state.getRawParameterValue("root")->load());
  for (int n = 0; n < 128; n++)
    notes.addItem(100 + n,
                  juce::String(n) + " / " +
                      juce::MidiMessage::getMidiNoteName(n, true, false, 3),
                  true, n == root);
  menu.addSubMenu("Sample root MIDI: " + juce::String(root), notes);
  menu.addSeparator();
  menu.addItem(1, "Import WAV...");
  menu.addItem(2, "Open preset...");
  menu.addItem(3, "Save preset...");
  menu.addItem(4, "Open preset folder");
  menu.addItem(5, "Open sample storage");
  menu.addSeparator();
  menu.addItem(6, processor.statusText(), false);
  menu.addItem(7, "JAV-BUZZ 0.4.0 / JAV UNIVERSE", false);
  menu.showMenuAsync(
      juce::PopupMenu::Options().withTargetComponent(optionsButton),
      [safe = juce::Component::SafePointer<Editor>(this)](int id) {
        if (!safe)
          return;
        if (id >= 100 && id < 228) {
          auto *p = safe->processor.state.getParameter("root");
          p->beginChangeGesture();
          p->setValueNotifyingHost(p->convertTo0to1(float(id - 100)));
          p->endChangeGesture();
        } else if (id == 1)
          safe->chooseWave();
        else if (id == 2)
          safe->choosePreset();
        else if (id == 3)
          safe->chooseSave();
        else if (id == 4)
          safe->processor.presetFolder().startAsProcess();
        else if (id == 5)
          safe->processor.sampleFolder().startAsProcess();
      });
}
void Editor::refreshPresets() {
  presetFiles = processor.presetFolder().findChildFiles(juce::File::findFiles,
                                                        false, "*.javpreset");
  presets.clear(juce::dontSendNotification);
  presets.addItem("INIT BASS", 1);
  presets.addItem("Open preset...", 2);
  presets.addSeparator();
  for (int i = 0; i < presetFiles.size(); i++)
    presets.addItem(presetFiles[i].getFileNameWithoutExtension(), 10 + i);
  presets.setSelectedId(1, juce::dontSendNotification);
}
void Editor::report(const juce::Result &r) {
  if (r.failed()) {
    notice = r.getErrorMessage();
    noticeFrames = 240;
    importButton.setTooltip(notice);
  }
}
void Editor::chooseWave() {
  chooser = std::make_unique<juce::FileChooser>(
      "Import bass WAV", processor.sampleFolder(), "*.wav");
  chooser->launchAsync(juce::FileBrowserComponent::openMode |
                           juce::FileBrowserComponent::canSelectFiles,
                       [safe = juce::Component::SafePointer<Editor>(this)](
                           const juce::FileChooser &c) {
                         if (safe && c.getResult().existsAsFile()) {
                           safe->processor.importWav(c.getResult());
                           safe->presets.setText("CUSTOM WAV",
                                                 juce::dontSendNotification);
                         }
                       });
}
void Editor::chooseSave() {
  chooser = std::make_unique<juce::FileChooser>(
      "Save JAV-BUZZ preset",
      processor.presetFolder().getChildFile("My Bass.javpreset"),
      "*.javpreset");
  chooser->launchAsync(
      juce::FileBrowserComponent::saveMode |
          juce::FileBrowserComponent::canSelectFiles |
          juce::FileBrowserComponent::warnAboutOverwriting,
      [safe = juce::Component::SafePointer<Editor>(this)](
          const juce::FileChooser &c) {
        if (safe && c.getResult() != juce::File()) {
          auto f = c.getResult().withFileExtension("javpreset");
          auto r = safe->processor.savePreset(f);
          safe->report(r);
          if (r.wasOk()) {
            safe->refreshPresets();
            safe->presets.setText(f.getFileNameWithoutExtension(),
                                  juce::dontSendNotification);
            safe->notice = "Preset + WAV saved";
            safe->noticeFrames = 90;
          }
        }
      });
}
void Editor::choosePreset() {
  chooser = std::make_unique<juce::FileChooser>(
      "Open JAV-BUZZ preset", processor.presetFolder(), "*.javpreset");
  chooser->launchAsync(juce::FileBrowserComponent::openMode |
                           juce::FileBrowserComponent::canSelectFiles,
                       [safe = juce::Component::SafePointer<Editor>(this)](
                           const juce::FileChooser &c) {
                         if (safe && c.getResult().existsAsFile()) {
                           auto r = safe->processor.loadPreset(c.getResult());
                           safe->report(r);
                           if (r.wasOk())
                             safe->presets.setText(
                                 c.getResult().getFileNameWithoutExtension(),
                                 juce::dontSendNotification);
                         }
                       });
}
