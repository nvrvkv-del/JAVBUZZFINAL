#include "Processor.h"
#include "Editor.h"
#include <stdexcept>
juce::AudioProcessorValueTreeState::ParameterLayout Processor::layout() {
  juce::AudioProcessorValueTreeState::ParameterLayout p;
  p.add(std::make_unique<juce::AudioParameterFloat>(
      juce::ParameterID{"gain", 1}, "Gain",
      juce::NormalisableRange<float>(-36, 6, .01f), -9));
  p.add(std::make_unique<juce::AudioParameterFloat>(
      juce::ParameterID{"dist", 1}, "Disst",
      juce::NormalisableRange<float>(0, 1, .001f), .25f));
  p.add(std::make_unique<juce::AudioParameterFloat>(
      juce::ParameterID{"filt", 1}, "Filth",
      juce::NormalisableRange<float>(-1, 1, .001f), 0));
  p.add(std::make_unique<juce::AudioParameterFloat>(
      juce::ParameterID{"reverb", 1}, "Wet",
      juce::NormalisableRange<float>(0, 1, .001f), 0));
  p.add(std::make_unique<juce::AudioParameterBool>(
      juce::ParameterID{"angel", 1}, "Angel fifth", false));
  p.add(std::make_unique<juce::AudioParameterBool>(
      juce::ParameterID{"demon", 1}, "Demon octave", false));
  p.add(std::make_unique<juce::AudioParameterInt>(
      juce::ParameterID{"root", 1}, "Sample root MIDI", 0, 127, 36));
  return p;
}
Processor::Processor()
    : AudioProcessor(BusesProperties().withOutput(
          "Output", juce::AudioChannelSet::stereo(), true)),
      Thread("JAV-BUZZ sample preparation"),
      state(*this, nullptr, "JAV_BUZZ_STATE", layout()) {
  static_assert(std::atomic<const jav::Sample *>::is_always_lock_free);
  static_assert(std::atomic<float>::is_always_lock_free);
  const char *ids[] = {"gain",  "dist",  "filt", "reverb",
                       "angel", "demon", "root"};
  for (int i = 0; i < 7; i++)
    params[i] = state.getRawParameterValue(ids[i]);
  for (auto &v : scope)
    v.store(0);
  formats.registerFormat(new juce::WavAudioFormat(), true);
  presetFolder().createDirectory();
  sampleFolder().createDirectory();
  request("", false);
  startThread();
}
Processor::~Processor() {
  signalThreadShouldExit();
  notify();
  stopThread(-1);
}
juce::File Processor::presetFolder() const {
  return juce::File::getSpecialLocation(
             juce::File::userApplicationDataDirectory)
      .getChildFile("JAV UNIVERSE/JAV-BUZZ/Presets");
}
juce::File Processor::sampleFolder() const {
  return presetFolder().getSiblingFile("Samples");
}
bool Processor::isBusesLayoutSupported(const BusesLayout &b) const {
  return b.getMainOutputChannelSet() == juce::AudioChannelSet::stereo() &&
         b.getMainInputChannelSet().isDisabled();
}
void Processor::prepareToPlay(double sr, int) {
  engine.prepare(sr);
  wasPlaying = false;
  setLatencySamples(jav::Engine::latency);
}
void Processor::processBlock(juce::AudioBuffer<float> &b,
                             juce::MidiBuffer &midi) {
  juce::ScopedNoDenormals nd;
  b.clear();
  const jav::Sample *s;
  do {
    s = current.load();
    hazard.store(s);
  } while (s != current.load());
  engine.setSample(s);
  engine.setRoot(int(params[6]->load()));
  if (auto *h = getPlayHead())
    if (auto p = h->getPosition()) {
      if (wasPlaying && !p->getIsPlaying())
        engine.allOff();
      wasPlaying = p->getIsPlaying();
    }
  jav::Controls p;
  p.gain = params[0]->load();
  p.disst = params[1]->load();
  p.filth = params[2]->load();
  p.wet = params[3]->load();
  p.angel = params[4]->load() > .5f;
  p.demon = params[5]->load() > .5f;
  auto it = midi.cbegin();
  const auto end = midi.cend();
  float peak = 0;
  for (int i = 0; i < b.getNumSamples(); i++) {
    while (it != end && (*it).samplePosition <= i) {
      const auto m = *it;
      if (m.numBytes >= 3) {
        int type = m.data[0] & 240, ch = (m.data[0] & 15) + 1,
            n = m.data[1] & 127, v = m.data[2] & 127;
        if (type == 144 && v)
          engine.on(n, v / 127.0f, ch);
        else if (type == 128 || (type == 144 && !v))
          engine.off(n, ch);
        else if (type == 176 && (n == 120 || n == 123))
          engine.allOff();
      }
      ++it;
    }
    const auto out = engine.tick(p);
    for (int c = 0; c < std::min(2, b.getNumChannels()); c++) {
      b.setSample(c, i, out[c]);
      peak = std::max(peak, std::abs(out[c]));
    }
    if (++scopeCounter % 8 == 0) {
      const auto w = scopeWrite.load(std::memory_order_relaxed);
      scope[w % 256].store((out[0] + out[1]) * .5f, std::memory_order_relaxed);
      scopeWrite.store(w + 1, std::memory_order_release);
    }
  }
  hazard.store(nullptr);
  level.store(std::max(level.load(), peak));
  midi.clear();
}
void Processor::processBlockBypassed(juce::AudioBuffer<float> &b,
                                     juce::MidiBuffer &m) {
  engine.reset();
  b.clear();
  m.clear();
  level.store(0);
}
void Processor::request(const juce::String &f, bool copy) {
  const juce::ScopedLock guard(lock);
  path = f;
  pendingPath = f;
  copyImport = copy;
  pending = true;
  ++requestId;
  status = "Preparing stretched sustain...";
  notify();
}
void Processor::importWav(const juce::File &f) {
  request(f.getFullPathName(), true);
}
juce::String Processor::statusText() const {
  const juce::ScopedLock guard(lock);
  return status;
}
std::array<float, 128> Processor::sampleShape() const {
  const juce::ScopedLock guard(lock);
  return shape;
}
void Processor::collect() {
  const auto *now = current.load();
  const auto *reading = hazard.load();
  owned.erase(std::remove_if(owned.begin(), owned.end(),
                             [&](auto &x) {
                               return x.get() != now && x.get() != reading;
                             }),
              owned.end());
}
void Processor::run() {
  while (!threadShouldExit()) {
    juce::String target;
    bool work = false, copy = false;
    unsigned id = 0;
    {
      const juce::ScopedLock guard(lock);
      work = pending;
      if (work) {
        pending = false;
        target = pendingPath;
        copy = copyImport;
        id = requestId;
      }
    }
    if (work) {
      std::unique_ptr<jav::Sample> sample;
      juce::String message;
      juce::String resolved = target;
      std::array<float, 128> preview{};
      try {
        sample = std::make_unique<jav::Sample>();
        sample->revision = revision++;
        if (target.isEmpty()) {
          sample->rate = 48000;
          for (auto &c : sample->raw) {
            c.resize(48000);
            for (int i = 0; i < 48000; i++) {
              const double t = i / 48000.0;
              c[i] = float((.5 * std::sin(2 * jav::pi * 65.406391 * t) +
                            .09 * std::sin(2 * jav::pi * 130.812782 * t)) *
                           std::exp(-t * 2));
            }
          }
          message = "INIT BASS | root 36";
        } else {
          const juce::File file(target);
          std::unique_ptr<juce::AudioFormatReader> r(
              formats.createReaderFor(file));
          if (!r)
            throw std::runtime_error(
                "Missing/unreadable WAV. Use the import icon to locate it.");
          if (r->numChannels < 1 || r->numChannels > 2 ||
              r->sampleRate < 8000 || r->sampleRate > 192000 ||
              r->lengthInSamples < 8 || r->lengthInSamples > r->sampleRate * 30)
            throw std::runtime_error(
                "Use mono/stereo WAV, 8-192 kHz, up to 30 seconds.");
          sample->rate = r->sampleRate;
          juce::AudioBuffer<float> data(2, int(r->lengthInSamples));
          if (!r->read(&data, 0, data.getNumSamples(), 0, true, true))
            throw std::runtime_error("WAV decoding failed.");
          for (int c = 0; c < 2; c++) {
            auto *start = data.getReadPointer(r->numChannels == 1 ? 0 : c);
            sample->raw[c].assign(start, start + data.getNumSamples());
            for (auto &x : sample->raw[c])
              x = jav::clamp(x, -2, 2);
          }
          message = file.getFileName();
          if (copy && !file.isAChildOf(sampleFolder())) {
            const auto dest = sampleFolder().getNonexistentChildFile(
                file.getFileNameWithoutExtension(), ".wav");
            if (!file.copyFileTo(dest))
              throw std::runtime_error(
                  "Could not copy WAV into the managed Samples folder.");
            resolved = dest.getFullPathName();
          }
        }
        for (int i = 0; i < 128; i++) {
          const auto &d = sample->raw[0];
          const size_t begin = size_t(i) * d.size() / 128,
                       end =
                           std::max(begin + 1, size_t(i + 1) * d.size() / 128);
          float max = 0;
          for (size_t j = begin; j < std::min(end, d.size()); j++)
            max = std::max(max, std::abs(d[j]));
          preview[i] = max;
        }
        jav::stretch(*sample);
        message += " | ready";
      } catch (const std::exception &e) {
        sample.reset();
        message = e.what();
      }
      {
        const juce::ScopedLock guard(lock);
        if (id == requestId) {
          const auto *ptr = sample.get();
          if (sample)
            owned.push_back(std::move(sample));
          current.store(ptr);
          path = resolved;
          shape = preview;
          status = message;
        }
      }
      collect();
    }
    collect();
    wait(80);
  }
}
void Processor::getStateInformation(juce::MemoryBlock &dest) {
  auto tree = state.copyState();
  {
    const juce::ScopedLock guard(lock);
    tree.setProperty("samplePath", path, nullptr);
  }
  tree.setProperty("schema", 1, nullptr);
  if (auto xml = tree.createXml())
    copyXmlToBinary(*xml, dest);
}
void Processor::setStateInformation(const void *data, int size) {
  if (auto xml = getXmlFromBinary(data, size)) {
    auto tree = juce::ValueTree::fromXml(*xml);
    if (!tree.hasType("JAV_BUZZ_STATE"))
      return;
    state.replaceState(tree);
    request(tree.getProperty("samplePath").toString(), false);
  }
}
juce::Result Processor::savePreset(const juce::File &file) {
  auto tree = state.copyState();
  juce::String src;
  {
    const juce::ScopedLock guard(lock);
    src = path;
  }
  if (!src.isEmpty()) {
    const juce::File wave(src);
    if (!wave.existsAsFile())
      return juce::Result::fail("Sample is missing; load it before saving.");
    const auto folder = file.getParentDirectory().getChildFile("Samples");
    auto result = folder.createDirectory();
    if (result.failed())
      return result;
    const auto dest = folder.getNonexistentChildFile(
        wave.getFileNameWithoutExtension(), ".wav");
    if (!wave.copyFileTo(dest))
      return juce::Result::fail("Could not save preset sample.");
    tree.setProperty("samplePath",
                     dest.getRelativePathFrom(file.getParentDirectory()),
                     nullptr);
  } else
    tree.setProperty("samplePath", "", nullptr);
  tree.setProperty("schema", 1, nullptr);
  auto xml = tree.createXml();
  if (!xml)
    return juce::Result::fail("Could not encode preset.");
  juce::TemporaryFile temp(file);
  if (!temp.getFile().replaceWithText(xml->toString()) ||
      !temp.overwriteTargetFileWithTemporary())
    return juce::Result::fail("Could not write preset.");
  return juce::Result::ok();
}
juce::Result Processor::loadPreset(const juce::File &file) {
  auto xml = juce::XmlDocument::parse(file);
  if (!xml)
    return juce::Result::fail("Invalid preset XML.");
  auto tree = juce::ValueTree::fromXml(*xml);
  if (!tree.hasType("JAV_BUZZ_STATE") ||
      int(tree.getProperty("schema", 0)) != 1)
    return juce::Result::fail("Unsupported JAV-BUZZ preset.");
  const auto stored = tree.getProperty("samplePath").toString();
  juce::String resolved;
  if (stored.isNotEmpty()) {
    const auto wave = file.getParentDirectory().getChildFile(stored);
    if (!wave.existsAsFile())
      return juce::Result::fail("Preset sample is missing. Keep its Samples "
                                "folder beside the preset.");
    resolved = wave.getFullPathName();
  }
  state.replaceState(tree);
  request(resolved, false);
  return juce::Result::ok();
}
void Processor::initPreset() {
  for (auto *p : getParameters())
    p->setValueNotifyingHost(p->getDefaultValue());
  request("", false);
}
juce::AudioProcessorEditor *Processor::createEditor() {
  return new Editor(*this);
}
juce::AudioProcessor *JUCE_CALLTYPE createPluginFilter() {
  return new Processor();
}
