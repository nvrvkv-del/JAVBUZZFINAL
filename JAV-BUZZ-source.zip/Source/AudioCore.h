#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <vector>
namespace jav {
constexpr double pi = 3.14159265358979323846;
inline float finite(float x) noexcept { return std::isfinite(x) ? x : 0.0f; }
inline float clamp(float x, float a, float b) noexcept {
  return std::clamp(finite(x), a, b);
}
struct Sample {
  std::array<std::vector<float>, 2> raw, body;
  double rate = 48000;
  std::uint64_t revision = 0;
};
// Runs only on the loader thread. WSOLA-like correlation-aligned overlap-add.
// The output has a finite end: the audio callback never wraps a sample cursor.
inline void stretch(Sample &s) {
  const int n = int(s.raw[0].size());
  if (n < 128) {
    s.body = s.raw;
    for (auto &c : s.body)
      for (int i = 0; i < n; i++)
        c[i] *= float(n - 1 - i) / std::max(1, n - 1);
    return;
  }
  const int win = std::min(n / 3, std::max(128, int(s.rate * .05))),
            hop = win / 2;
  const int target = std::max(n, std::min(n * 8, int(s.rate * 12)));
  if (target == n) {
    s.body = s.raw;
    const int fade = std::min(n, int(s.rate * .25));
    for (auto &c : s.body)
      for (int i = 0; i < fade; i++)
        c[n - fade + i] *=
            float(.5 + .5 * std::cos(pi * i / std::max(1, fade - 1)));
    return;
  }
  const double factor = double(target - win) / std::max(1, n - win);
  for (int c = 0; c < 2; c++) {
    s.body[c].assign(target, 0);
    std::copy_n(s.raw[c].begin(), win, s.body[c].begin());
  }
  for (int dst = hop; dst < target; dst += hop) {
    const int nominal = std::clamp(int(dst / factor), 0, n - win);
    int best = nominal;
    double bestScore = -2;
    const int lo = std::max(0, nominal - win / 4),
              hi = std::min(n - win, nominal + win / 4);
    // Coarse search then a full-resolution local refinement; compare both
    // channels.
    auto score = [&](int at) {
      double cross = 0, aa = 1e-12, bb = 1e-12;
      for (int j = 0; j < hop && dst + j < target; j += 8)
        for (int c = 0; c < 2; c++) {
          const double a = s.body[c][dst + j], b = s.raw[c][at + j];
          cross += a * b;
          aa += a * a;
          bb += b * b;
        }
      return cross / std::sqrt(aa * bb);
    };
    for (int at = lo; at <= hi; at += 8) {
      const double v = score(at);
      if (v > bestScore) {
        bestScore = v;
        best = at;
      }
    }
    const int coarse = best;
    for (int at = std::max(lo, coarse - 7); at <= std::min(hi, coarse + 7);
         ++at) {
      const double v = score(at);
      if (v > bestScore) {
        bestScore = v;
        best = at;
      }
    }
    for (int j = 0; j < win && dst + j < target; j++) {
      const float w = j < hop ? float(.5 - .5 * std::cos(pi * j / hop)) : 1.0f;
      for (int c = 0; c < 2; c++)
        s.body[c][dst + j] =
            (1 - w) * s.body[c][dst + j] + w * s.raw[c][best + j];
    }
  }
  // Gentle long fade prevents an artificial held plateau and a hard file
  // endpoint.
  const int fadeStart = target / 2;
  for (int i = fadeStart; i < target; i++) {
    const float f =
        float(.5 + .5 * std::cos(pi * (i - fadeStart) /
                                 std::max(1, target - fadeStart - 1)));
    for (auto &c : s.body)
      c[i] *= f;
  }
}
struct Controls {
  float gain = -9, disst = .25f, filth = 0, wet = 0;
  bool angel = false, demon = false;
};
struct Smooth {
  float value = 0, a = .001f;
  void prepare(double rate, float seconds, float v) {
    a = float(1 - std::exp(-1 / (rate * seconds)));
    value = v;
  }
  float tick(float target) noexcept {
    value += a * (target - value);
    return value;
  }
};
struct SVF {
  float ic1 = 0, ic2 = 0;
  void reset() { ic1 = ic2 = 0; }
  std::array<float, 2> tick(float x, float cutoff, double sr) noexcept {
    const float g = float(std::tan(
                    pi * std::clamp(double(cutoff), 10.0, sr * .44) / sr)),
                k = 1.41421356f, a1 = 1 / (1 + g * (g + k)),
                v1 = a1 * (ic1 + g * (x - ic2)), v2 = ic2 + g * v1;
    ic1 = 2 * v1 - ic1;
    ic2 = 2 * v2 - ic2;
    return {v2, x - k * v1 - v2};
  }
};
class Engine {
public:
  void prepare(double sampleRate) {
    sr = sampleRate;
    rate = sr * 2;
    smoothG.prepare(rate, .015f, -9);
    smoothD.prepare(rate, .018f, .25f);
    smoothF.prepare(rate, .018f, 0);
    smoothW.prepare(rate, .03f, 0);
    for (auto &h : harm)
      h.prepare(rate, .02f, 0);
    splitA = float(1 - std::exp(-2 * pi * 100 / rate));
    dcA = float(std::exp(-2 * pi * 12 / rate));
    for (int c = 0; c < 2; c++) {
      chorus[c].assign(size_t(rate * .04) + 4, 0);
      for (int j = 0; j < 4; j++)
        rev[c][j].assign(size_t(rate * (.0277 + .0101 * j + .0013 * c)), 0);
    }
    float sum = 0;
    for (int i = 0; i < 33; i++) {
      double x = i - 16;
      const double v = x == 0 ? .45 : std::sin(2 * pi * .225 * x) / (pi * x);
      fir[i] = float(v * (.42 - .5 * std::cos(2 * pi * i / 32) +
                          .08 * std::cos(4 * pi * i / 32)));
      sum += fir[i];
    }
    for (auto &x : fir)
      x /= sum;
    reset();
  }
  void reset() noexcept {
    held.fill(0);
    velocities.fill(0);
    serial = 0;
    active = -1;
    positions.fill(0);
    env = 0;
    last = {};
    tail = {};
    xfade = 0;
    sub = {};
    dcIn = {};
    dcOut = {};
    for (auto &f : filters)
      f.reset();
    for (auto &f : wetFilter)
      f.reset();
    for (auto &c : chorus)
      std::fill(c.begin(), c.end(), 0);
    for (auto &c : rev)
      for (auto &b : c)
        std::fill(b.begin(), b.end(), 0);
    revPos = {};
    damp = {};
    history = {};
    histPos = chorusPos = 0;
    phase = 0;
  }
  void setSample(const Sample *s) noexcept {
    if ((s ? s->revision : 0) != revision) {
      reset();
      revision = s ? s->revision : 0;
    }
    sample = s;
  }
  void setRoot(int n) noexcept { root = std::clamp(n, 0, 127); }
  void on(int note, float velocity, int channel = 1) noexcept {
    if (note < 0 || note > 127 || channel < 1 || channel > 16)
      return;
    int key = (channel - 1) * 128 + note;
    held[key] = ++serial;
    velocities[key] = clamp(velocity, 0, 1);
    start(key);
  }
  void off(int note, int channel = 1) noexcept {
    if (note < 0 || note > 127 || channel < 1 || channel > 16)
      return;
    int key = (channel - 1) * 128 + note;
    held[key] = 0;
    if (active != key)
      return;
    int next = -1;
    std::uint64_t age = 0;
    for (int i = 0; i < 2048; i++)
      if (held[i] > age) {
        age = held[i];
        next = i;
      }
    if (next >= 0)
      start(next);
    else
      active = -1;
  }
  void allOff() noexcept {
    held.fill(0);
    active = -1;
  }
  std::array<float, 2> tick(const Controls &p) noexcept {
    for (int oversample = 0; oversample < 2; oversample++) {
      const auto y = internal(p);
      histPos = (histPos + 1) % 33;
      for (int c = 0; c < 2; c++)
        history[c][histPos] = y[c];
    }
    std::array<float, 2> out{};
    for (int c = 0; c < 2; c++)
      for (int j = 0; j < 33; j++)
        out[c] += fir[j] * history[c][(histPos + 33 - j) % 33];
    return out;
  }
  static constexpr int latency = 8;

private:
  void start(int key) noexcept {
    tail = last;
    xfade = 1;
    positions.fill(0);
    env = 0;
    active = playing = key;
    velocity = velocities[key];
  }
  float read(int c, double p) const noexcept {
    const auto &v = sample->body[c];
    if (p < 0 || p >= double(v.size() - 1))
      return 0;
    int i = int(p);
    float t = float(p - i);
    auto at = [&](int k) { return v[std::clamp(k, 0, int(v.size()) - 1)]; };
    const float a = at(i - 1), b = at(i), cc = at(i + 1), d = at(i + 2);
    return b +
           .5f * t *
               (cc - a +
                t * (2 * a - 5 * b + 4 * cc - d + t * (3 * (b - cc) + d - a)));
  }
  std::array<float, 2> internal(const Controls &p) noexcept {
    const float d = smoothD.tick(clamp(p.disst, 0, 1)),
                f = smoothF.tick(clamp(p.filth, -1, 1)),
                wet = smoothW.tick(clamp(p.wet, 0, 1)),
                gain =
                    std::pow(10.0f, smoothG.tick(clamp(p.gain, -36, 6)) / 20);
    const int mode = p.angel ? (p.demon ? 3 : 1) : (p.demon ? 2 : 0);
    float weights[3];
    for (int i = 0; i < 3; i++)
      weights[i] = harm[i].tick(mode == i + 1 ? .85f : 0);
    env = active >= 0 ? std::min(1.0f, env + float(1 / (rate * .004)))
                      : std::max(0.0f, env - float(1 / (rate * .08)));
    const int offsets[] = {0, 7, 12, 10};
    std::array<float, 2> out{};
    for (int c = 0; c < 2; c++) {
      float fundamental = 0, harmony = 0;
      if (sample && !sample->body[c].empty()) {
        fundamental = read(c, positions[0]);
        for (int j = 0; j < 3; j++)
          harmony += weights[j] * read(c, positions[j + 1]);
      }
      // Brighter compressed harmony and a quiet modulated stereo chorus: 80s
      // character.
      harmony = std::tanh(harmony * 2.3f) * .65f;
      const float delay =
          float(rate * (.013 + .003 * std::sin(phase + c * pi * .5)));
      const int di = int(delay);
      const float frac = delay - di;
      const int size = int(chorus[c].size());
      float delayed = 0;
      if (size) {
        const int a = (chorusPos + size - di) % size, b = (a + size - 1) % size;
        delayed = chorus[c][a] * (1 - frac) + chorus[c][b] * frac;
        chorus[c][chorusPos] = harmony * env * velocity;
      }
      float x = (fundamental + harmony) * env * velocity + delayed * .3f;
      if (xfade > 0)
        x = x * (1 - xfade) + tail[c] * xfade;
      last[c] = x;
      sub[c] += splitA * (x - sub[c]);
      const float body = x - sub[c];
      const float drive = std::pow(10.0f, 1.65f * d), bias = .12f * d;
      float shaped = (std::tanh(body * drive + bias) - std::tanh(bias)) *
                     (.8f + .2f / std::sqrt(drive));
      const float fold = clamp((d - .45f) / .55f, 0, 1);
      shaped +=
          (std::sin(shaped * (1 + fold * 5)) * .8f - shaped) * fold * .55f;
      const float dc = shaped - dcIn[c] + dcA * dcOut[c];
      dcIn[c] = shaped;
      dcOut[c] = dc;
      const float mix = std::min(1.0f, d * 3);
      const float colored = body + (dc - body) * mix;
      const float amount = std::abs(f);
      const float cutoff = f < 0
                               ? float(18000 * std::pow(120.0 / 18000, amount))
                               : float(25 * std::pow(4000.0 / 25, amount));
      const auto filtered = filters[c].tick(colored, cutoff, rate);
      const float filterMix = std::min(1.0f, amount * 12);
      const float result =
          sub[c] + colored +
          filterMix * ((f < 0 ? filtered[0] : filtered[1]) - colored);
      const float send = wetFilter[c].tick(result, 220, rate)[1];
      float room = 0;
      for (int j = 0; j < 4; j++) {
        auto &line = rev[c][j];
        auto &pos = revPos[c][j];
        if (line.empty())
          continue;
        const float old = line[pos];
        damp[c][j] += .12f * (old - damp[c][j]);
        line[pos] = send * .18f + damp[c][j] * (.70f - .045f * j);
        pos = (pos + 1) % line.size();
        room += old;
      }
      out[c] = finite((result + room * wet * 1.2f) * gain);
    }
    if (sample) {
      for (int j = 0; j < 4; j++) {
        const double detune = j == 0 ? 0 : 5.0 * std::sin(phase * .37);
        const double step =
            sample->rate / rate *
            std::pow(2.0,
                     ((playing % 128) - root + offsets[j] + detune / 100) / 12);
        positions[j] =
            std::min(positions[j] + step, double(sample->body[0].size()));
      }
    }
    xfade = std::max(0.0f, xfade - float(1 / (rate * .004)));
    if (!chorus[0].empty())
      chorusPos = (chorusPos + 1) % int(chorus[0].size());
    phase += 2 * pi * .65 / rate;
    if (phase > 2 * pi)
      phase -= 2 * pi;
    return out;
  }
  const Sample *sample = nullptr;
  std::uint64_t revision = 0, serial = 0;
  double sr = 48000, rate = 96000, phase = 0;
  int root = 36, active = -1, playing = 36, chorusPos = 0, histPos = 0;
  float env = 0, velocity = 0, xfade = 0, splitA = 0, dcA = 0;
  std::array<std::uint64_t, 2048> held{};
  std::array<float, 2048> velocities{};
  std::array<double, 4> positions{};
  std::array<float, 2> last{}, tail{}, sub{}, dcIn{}, dcOut{};
  Smooth smoothG, smoothD, smoothF, smoothW;
  std::array<Smooth, 3> harm;
  std::array<SVF, 2> filters, wetFilter;
  std::array<std::vector<float>, 2> chorus;
  std::array<std::array<std::vector<float>, 4>, 2> rev;
  std::array<std::array<size_t, 4>, 2> revPos{};
  std::array<std::array<float, 4>, 2> damp{};
  std::array<float, 33> fir{};
  std::array<std::array<float, 33>, 2> history{};
};
} // namespace jav
