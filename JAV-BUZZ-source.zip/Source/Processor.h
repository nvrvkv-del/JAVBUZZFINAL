#pragma once
#include "AudioCore.h"
#include <JuceHeader.h>
class Processor final : public juce::AudioProcessor, private juce::Thread {
public:
  Processor();
  ~Processor() override;
  void prepareToPlay(double, int) override;
  void releaseResources() override {};
  void processBlock(juce::AudioBuffer<float> &, juce::MidiBuffer &) override;
  void processBlockBypassed(juce::AudioBuffer<float> &,
                            juce::MidiBuffer &) override;
  bool isBusesLayoutSupported(const BusesLayout &) const override;
  const juce::String getName() const override { return "JAV-BUZZ"; }
  bool acceptsMidi() const override { return true; }
  bool producesMidi() const override { return false; }
  bool isMidiEffect() const override { return false; }
  bool hasEditor() const override { return true; }
  juce::AudioProcessorEditor *createEditor() override;
  double getTailLengthSeconds() const override { return 3; }
  int getNumPrograms() override { return 1; }
  int getCurrentProgram() override { return 0; }
  void setCurrentProgram(int) override {}
  const juce::String getProgramName(int) override { return "INIT"; }
  void changeProgramName(int, const juce::String &) override {}
  void getStateInformation(juce::MemoryBlock &) override;
  void setStateInformation(const void *, int) override;
  void importWav(const juce::File &);
  juce::Result savePreset(const juce::File &);
  juce::Result loadPreset(const juce::File &);
  void initPreset();
  juce::String statusText() const;
  std::array<float, 128> sampleShape() const;
  juce::File presetFolder() const;
  juce::File sampleFolder() const;
  juce::AudioProcessorValueTreeState state;
  std::array<std::atomic<float>, 256> scope{};
  std::atomic<unsigned> scopeWrite{0};
  std::atomic<float> level{0};

private:
  static juce::AudioProcessorValueTreeState::ParameterLayout layout();
  void request(const juce::String &, bool copy);
  void run() override;
  void collect();
  mutable juce::CriticalSection lock;
  juce::String path, pendingPath, status = "Loading demo bass...";
  bool pending = false, copyImport = false;
  unsigned requestId = 0;
  std::array<float, 128> shape{};
  juce::AudioFormatManager formats;
  std::vector<std::unique_ptr<jav::Sample>> owned;
  std::atomic<const jav::Sample *> current{nullptr}, hazard{nullptr};
  std::uint64_t revision = 1;
  jav::Engine engine;
  std::array<std::atomic<float> *, 7> params{};
  bool wasPlaying = false;
  unsigned scopeCounter = 0;
  JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(Processor)
};
