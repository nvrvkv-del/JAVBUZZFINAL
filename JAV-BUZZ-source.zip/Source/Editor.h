#pragma once
#include "Processor.h"

class Editor final : public juce::AudioProcessorEditor,
                     private juce::Timer,
                     public juce::FileDragAndDropTarget {
public:
  explicit Editor(Processor &);
  ~Editor() override;
  void paint(juce::Graphics &) override;
  void resized() override;
  bool isInterestedInFileDrag(const juce::StringArray &) override;
  void filesDropped(const juce::StringArray &, int, int) override;

private:
  struct SkinLook : juce::LookAndFeel_V4 {
    juce::Image dial;
    void drawRotarySlider(juce::Graphics &, int, int, int, int, float, float,
                          float, juce::Slider &) override;
    void drawComboBox(juce::Graphics &, int, int, bool, int, int, int, int,
                      juce::ComboBox &) override;
    void positionComboBoxText(juce::ComboBox &, juce::Label &) override;
    juce::Font getComboBoxFont(juce::ComboBox &) override;
    void drawButtonBackground(juce::Graphics &, juce::Button &,
                              const juce::Colour &, bool, bool) override;
    void drawButtonText(juce::Graphics &, juce::TextButton &, bool,
                        bool) override;
  };
  struct Spirit : juce::Button {
    explicit Spirit(int r) : Button(r == 0 ? "Angel" : "Demon"), row(r) {
      setClickingTogglesState(true);
    }
    void paintButton(juce::Graphics &, bool, bool) override;
    void advance(int mode, float dt);
    juce::Image sprites;
    int row;
    std::array<float, 3> opacity{{1, 0, 0}};
    float lift = 0;
  };
  void timerCallback() override;
  void refreshPresets();
  void chooseWave();
  void chooseSave();
  void choosePreset();
  void showOptions();
  void report(const juce::Result &);
  void drawScope(juce::Graphics &);
  Processor &processor;
  SkinLook look;
  juce::TooltipWindow tooltip{this, 600};
  juce::Image panel;
  Spirit angel{0}, demon{1};
  std::array<juce::Slider, 4> knobs;
  juce::ComboBox presets;
  juce::TextButton importButton{""}, saveButton{"save"},
      optionsButton{"options"};
  std::array<
      std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>, 4>
      knobAttachments;
  std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>
      angelAttachment, demonAttachment;
  std::unique_ptr<juce::FileChooser> chooser;
  juce::Array<juce::File> presetFiles;
  std::array<std::array<float, 256>, 3> traces{};
  std::array<float, 128> shape{};
  float energy = 0;
  double lastFrame = 0;
  juce::String notice, currentStatus;
  int noticeFrames = 0;
  JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(Editor)
};
