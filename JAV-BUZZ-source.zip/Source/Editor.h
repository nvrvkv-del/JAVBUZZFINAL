#pragma once
#include "Processor.h"
class Editor final : public juce::AudioProcessorEditor, private juce::Timer {
public:
  explicit Editor(Processor &);
  ~Editor() override;
  void paint(juce::Graphics &) override;
  void resized() override;

private:
  struct KnobLook : juce::LookAndFeel_V4 {
    void drawButtonText(juce::Graphics &, juce::TextButton &, bool,
                        bool) override;
    void drawRotarySlider(juce::Graphics &, int, int, int, int, float, float,
                          float, juce::Slider &) override;
  };
  struct Spirit : juce::Button {
    Spirit(bool a) : Button(a ? "Angel" : "Demon"), angel(a) {
      setClickingTogglesState(true);
    }
    void paintButton(juce::Graphics &, bool, bool) override;
    bool angel;
    float awake = 0;
    bool alien = false;
  };
  void timerCallback() override;
  void refreshPresets();
  void chooseWave();
  void chooseSave();
  void choosePreset();
  void report(const juce::Result &);
  Processor &processor;
  KnobLook look;
  juce::TooltipWindow tooltip{this, 650};
  juce::Image character;
  Spirit angel{true}, demon{false};
  std::array<juce::Slider, 4> knobs;
  juce::ComboBox presets, root;
  juce::TextButton importButton{""}, saveButton{"SAVE"}, folderButton{"DIR"};
  juce::Label status;
  std::array<
      std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>, 4>
      knobAttachments;
  std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>
      angelAttachment, demonAttachment;
  std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment>
      rootAttachment;
  std::unique_ptr<juce::FileChooser> chooser;
  juce::Array<juce::File> presetFiles;
  float energy = 0, phase = 0;
  juce::String notice;
  int noticeFrames = 0;
  JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(Editor)
};
