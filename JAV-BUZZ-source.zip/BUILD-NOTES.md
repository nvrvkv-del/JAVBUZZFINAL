# JAV-BUZZ 0.4.0

This update replaces the plain drawn panel with embedded illustrated PNG assets
and fixes the response of the controls during held notes. Same vendor, plugin
identifier and parameter IDs as 0.3.0. Windows x64 VST3 instrument.

## Changes

The previous DSP preserved a large low-frequency bypass, masking changes on
sub-bass samples. Disst now saturates the complete signal with only a small
clean-bass blend. Filth now crossfades into separate continuously running LP/HP
filters, so there is no shared filter-state mode switch at the centre. Effect
controls have 35–40 ms smoothing time constants; gain keeps its 15 ms smoothing.
The UI ranges have no artificial quantization steps, and targets are sampled
every 16 audio samples so large host buffers do not delay manual updates until
the next whole buffer. This does not claim sample-accurate host automation.

All four macro controls keep their IDs and ranges. Old presets load but can
sound different because the drive/filter behavior was deliberately corrected.

The panel uses real PNG skins and sprites with native interactive controls.
Default size is 400 x 657 pixels; aspect ratio is constrained when resized.
Preset/root/folder utilities are in the top strip and three-dot menu. WAV files
can be imported using the icon or drag-and-drop.

## Test scope

See VALIDATION.txt for the actual results of this update. The portable suite
checks core stability, sample completion, mode changes and callback allocations.
LiveControls checks parameter jumps and continuous sweeps on one held bass note,
plus Filth centre crossings at 16 phases. These are numerical tests, not a claim
of equal perceptual change with every sample or a guarantee of zero bugs.

PluginSmoke exercises real JUCE WAV loading, portable preset relocation, host
state recall, attached GUI knobs and renders all four character states. The
Windows workflow executes these tests before uploading the VST3 artifact.

Windows and Studio One verification of 0.4.0 must still be performed after that
build. The earlier 0.3.0 loaded in the user's Studio One, but that does not prove
this new build or every feature. The older browser preview is not updated here.

## Build

Dependency: JUCE 9.0.3, downloaded at build time with pinned SHA-256 in CMake.
JUCE license: https://github.com/juce-framework/JUCE/blob/9.0.3/LICENSE.md

Windows with Visual Studio 2022 C++ desktop tools and CMake:

```
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release --parallel 2
ctest --test-dir build -C Release --output-on-failure
```

Output: build/JAVBUZZ_artefacts/Release/VST3/JAV-BUZZ.vst3
Portable tests: configure with -DJAV_CORE_ONLY=ON, build, then run ctest.

Loader-thread sample preparation and atomic sample handover remain unchanged.
2x internal processing plus FIR downsampling reports eight samples latency.
This reduces but does not eliminate aliasing. Stretching is finite correlated
overlap-add, not unlimited sustain. Session states store sample paths; portable
presets copy WAVs alongside the XML. See QUICK-START.txt for usage and limits.
