# JAV-BUZZ 0.3.0 — test build

Rewritten C++17 JUCE instrument, stereo output, MIDI input, Windows x64 VST3.
Vendor metadata: JAV UNIVERSE. New plugin identifier: Jvbz / Javu.

## Verified in the available Linux environment

- CMake Release build of the independent DSP tests: PASS.
- 40 adjacent knob intervals change rendered audio: PASS (objective difference,
  not a claim that all steps sound equally strong to every listener).
- Distinct dry/fifth/octave/seventh output: PASS.
- Attack preservation, finite stretch length, fade endpoint and no sample
  restart after exhaustion: PASS.
- Extreme MIDI/control changes at 8, 22.05, 44.1, 48, 96 and 192 kHz: PASS.
- Empty/very short buffers, reset silence, and no C++ heap allocations in the
  exercised audio callback: PASS.
- AddressSanitizer and UndefinedBehaviorSanitizer: PASS.
  LeakSanitizer was disabled because this environment denies its /proc task
  inspection. This is not a leak-test pass.
- Processor, editor and Windows smoke-test sources: C++17 syntax check against
  actual JUCE 9.0.3 headers: PASS.
- Character artwork inspected. Panel layout reviewed in source.

## Not verified here

A Windows compiler, Studio One, and a native graphical runtime were not
available. No claim is made that the final VST3 has already compiled, loaded
in Studio One, or had its animations visually tested. This package contains
source, not a precompiled Windows plugin. The earlier browser preview has
not been updated by this package and is not evidence of VST3 behavior.

The supplied GitHub workflow builds Windows x64, executes both test programs,
and only uploads the plugin after tests pass. PluginSmoke tests actual JUCE
MIDI output, WAV loading, relocated preset samples, host-state restoration,
and writes sleep/angel/demon/aliens panel PNGs. Rendering snapshots does not
by itself prove all mouse interactions or animations work in Studio One.

## Architecture and limits

Sample reading, copies, correlation search and stretch preparation run on a
loader thread. Atomic current/hazard pointers protect sample lifetime while
playing; old samples are reclaimed off the audio thread. Audio parameters are
smoothed. The audio path uses 2x internal processing with FIR decimation and
reports eight samples of latency. This reduces, but does not eliminate,
distortion/pitch-shifting aliasing.

Stretching uses correlated overlap-add grains, at most 8x and at most 12 seconds
at the original sample pitch. Long files retain their natural duration. The
sample cursor never wraps. Transient-rich, noisy and very short sounds can
still produce grain artifacts. Audition with the user's actual one-shot pack.

Monophonic/latest-note-priority. The root pitch is set manually; no automatic
pitch detection. MIDI pitch bend, sustain-pedal control and MPE are not
implemented. Harmony voices rise by 7, 12 or 10 semitones; both switches are an
explicit minor-seventh mode. They share the prepared sample and finish sooner
at higher pitches. The original bass is always retained underneath.

Sample and preset changes prepare asynchronously. Wait for ready before
playing or starting an offline export. Missing files show a status error.
Preset WAV files are copied for portability; Studio One song state retains a
sample path rather than embedding the whole WAV. Save the Samples folder
with backups. Presets use schema 1 XML with the .javpreset extension.

## Build manually

Install CMake and Visual Studio 2022 C++ desktop tools, then run from the
extracted source directory:

```
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release --parallel 2
ctest --test-dir build -C Release --output-on-failure
```

VST3: build/JAVBUZZ_artefacts/Release/VST3/JAV-BUZZ.vst3

Portable DSP-only verification:

```
cmake -S . -B build-core -DJAV_CORE_ONLY=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build-core
ctest --test-dir build-core --output-on-failure
```

Dependency: JUCE 9.0.3, pinned archive SHA-256 in CMakeLists.txt.
https://github.com/juce-framework/JUCE/releases/tag/9.0.3
JUCE is downloaded at build time and has its own licensing terms:
https://github.com/juce-framework/JUCE/blob/9.0.3/LICENSE.md

Workflow actions are pinned to release tags:
https://github.com/actions/checkout/releases/tag/v7.0.1
https://github.com/actions/upload-artifact/releases/tag/v7.0.2

No third-party bass pack is bundled. INIT BASS is synthesized in the loader.
