# Artwork in 0.4.0

The real editor uses these embedded PNGs:
- Assets/Panel.png: cobalt blue textured skin, JAV-BUZZ lettering, skeleton,
  frames, import icon and footer.
- Assets/Spirits.png: three columns by two rows. Angel sleeping/awake/alien on
  row one; demon sleeping/awake/alien on row two. Transparent sprite sheet.
- Assets/Knob.png: textured black/yellow dial; the coloured pointer and fixed
  ticks are drawn at the current control angle.

Live waveform traces are rendered from the audio output, not baked into a PNG.
Character state transitions use crossfades and vertical motion at 40 Hz.
The main skeleton is intentionally static.

Character.png is the previous separate illustration, retained only because the
already-installed GitHub workflow checks that filename. It is not embedded in
the new plugin. It can be removed if that check is also changed in the workflow.

Artwork was created with the built-in image generator from the approved blue
comic reference. Prompts requested a static cobalt/pink/green panel without
baked controls, a six-cell transparent mascot sheet, and a transparent unmarked
dial matching the same distressed comic print. Integration, pointers, menus,
parameters and live waveform are native JUCE code.
