@echo off
setlocal
cd /d "%~dp0"
if not exist "JAV-BUZZ.vst3" (
 echo Extract the downloaded Windows artifact ZIP first.
 pause
 exit /b 1
)
set "JAV_TARGET=%CommonProgramFiles%\VST3\JAV UNIVERSE\JAV-BUZZ.vst3"
echo Close Studio One before installing.
echo Installing to "%JAV_TARGET%"
xcopy "JAV-BUZZ.vst3" "%JAV_TARGET%\" /E /I /Y >nul
if errorlevel 1 (
 echo Install failed. Right-click INSTALL.cmd and choose Run as administrator.
 pause
 exit /b 1
)
echo Installed. Open Studio One and rescan plug-ins.
echo Look in Instruments, vendor JAV UNIVERSE, for JAV-BUZZ.
pause
